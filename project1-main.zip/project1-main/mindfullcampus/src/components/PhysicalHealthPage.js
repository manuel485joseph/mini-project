import React from 'react';

function PhysicalHealthPage() {
  return (
    <div>
      <h2>Physical Health Page</h2>
    </div>
  );
}

export default PhysicalHealthPage;
