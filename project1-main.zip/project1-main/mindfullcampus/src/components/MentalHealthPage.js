import React from 'react';

function MenstrualHealthPage() {
  return (
    <div>
      <h2>Menstrual Health Page</h2>
      
    </div>
  );
}

export default MenstrualHealthPage;
